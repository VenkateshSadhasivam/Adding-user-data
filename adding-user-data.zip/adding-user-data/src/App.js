import React from 'react';
import { store, history } from 'redux/store';
import { Router, Switch } from 'react-router-dom';
import { Provider } from 'react-redux';
import AppRouter from "routes/AppRouter";

function App() {
  return (
      <Provider store={store}>
          <Router history={history}>
              <Switch>
                <AppRouter />
              </Switch>
          </Router>
      </Provider>
  );
}

export default App;
