import { all, takeEvery, put, delay } from 'redux-saga/effects';
import actions from 'redux/app/actions';
import { store } from 'redux/store'

export function* editUserDetails(params) {
    try {
        const { userDetail, editFormValue } = store.getState().App;
        yield delay ( 1000 );
        let newUserDetail = [params.payload].concat(userDetail.filter(detail=> detail.id !== editFormValue.id))
        yield put({
            type: actions.EDIT_USER_DETAIL_SUCCESS,
            payload: newUserDetail,
        });
    } catch (error) {
        yield put({
            type: actions.EDIT_USER_DETAIL_FAILURE,
        });
    }
}

export default function* rootSaga() {
    yield all([
        takeEvery(actions.EDIT_USER_DETAIL, editUserDetails),
    ]);
}
