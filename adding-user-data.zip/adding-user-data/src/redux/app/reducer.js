import actions from './actions';

const initState = {
  userDetail:[],
  selectedUserList: [],
  deleteModalVisible: false,
  editModalVisible: false,
  editFormValue: {},
};

export default function appReducer(state = initState, action) {
  switch (action.type) {
    case actions.ADD_NEW_USER: {
      return {
        ...state,
        userDetail: [action.payload, ...state.userDetail]
      };
    }
    case actions.USER_SELECTED_LIST: {
      return {
        ...state,
        selectedUserList: action.payload,
      }
    }
    case actions.REMOVE_USER_LIST: {
      return {
        ...state,
        userDetail: state.userDetail.filter(detail=> !state.selectedUserList.includes(detail.id)),
        selectedUserList: [],
        deleteModalVisible: false,
      }
    }
    case actions.DELETE_MODAL_VISIBLE: {
      return {
        ...state,
        deleteModalVisible: action.payload,
      }
    }
    case actions.EDIT_MODAL_VISIBLE: {
      return {
        ...state,
        editModalVisible: action.payload,
      }
    }
    case actions.SET_FORM_VALUE: {
      return {
        ...state,
        editFormValue: action.payload,
      }
    }
    case actions.EDIT_USER_DETAIL: {
      return {
        ...state,
        editLoader: true,
      }
    }
    case actions.EDIT_USER_DETAIL_SUCCESS: {
      return {
        ...state,
        editLoader: false,
        editModalVisible: false,
        editFormValue: {},
        userDetail: action.payload,
      }
    }
    case actions.EDIT_USER_DETAIL_FAILURE: {
      return {
        ...state,
        editLoader: false,
      }
    }
    default:
      return state;
  }
}
