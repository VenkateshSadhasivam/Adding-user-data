import App from 'redux/app/reducer';

export default { App };
