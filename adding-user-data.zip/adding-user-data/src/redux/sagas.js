import { all } from 'redux-saga/effects';
import app from 'redux/app/sagas';


export default function* rootSaga(getState) {
  yield all([ app() ]);
}
