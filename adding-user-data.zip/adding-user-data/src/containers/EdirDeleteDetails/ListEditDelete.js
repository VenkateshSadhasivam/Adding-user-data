import React from "react";
import ListTable from "components/ListDetails/ListTable";
import EditUser from "components/UserDetailEdit/EditFile";

const ListEditDetail = () =>
    <>
        <ListTable />
        <EditUser />
    </>

export default ListEditDetail;