import React from 'react';
import FormData from 'components/UserData/CreateUser'

const UserData = ()=>
    <div>
    <FormData />
</div>

export default UserData;