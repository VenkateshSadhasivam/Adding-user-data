import React from "react";
import { Table, Modal, Row, Col, PageHeader,Button } from 'antd';
import {useDispatch, useSelector} from "react-redux";
import { history } from 'redux/store';
import actions from 'redux/app/actions';

const ListTable = ()=> {
    const { userDetail,selectedUserList, deleteModalVisible } = useSelector(state=> state.App)
    const dispatch = useDispatch();
    const rowSelection = {
        onChange: (selectedRowKeys) => {
            dispatch({
                type: actions.USER_SELECTED_LIST,
                payload: selectedRowKeys,
            });
        },
        selectedRowKeys: selectedUserList,
    };
    const onSetPreformData = (data) =>{
        dispatch({
            type: actions.EDIT_MODAL_VISIBLE,
            payload: true,
        })
        dispatch({
            type: actions.SET_FORM_VALUE,
            payload: {
                username: data.username,
                phone: data.phone,
                prefix: data.prefix,
                address: data.address,
                id: data.id
            }
        })
    }
    const columns = [
        {
            title: 'User Name',
            dataIndex: 'username',
            key: 'username',
        },
        {
            title: 'Phone Number',
            dataIndex: 'phoneNumber',
            key: 'phoneNumber',
        },
        {
            title: 'Address',
            dataIndex: 'address',
            key: 'address',
        },
        {
            title: 'Action',
            dataIndex: 'id',
            key: 'id',
            render:(text, rowData) =>{
               return <Button onClick={()=>onSetPreformData(rowData)}>Edit</Button>
            }
        }
    ];
    return (
      <>
        <PageHeader
            title={'List Details'}
            onBack={()=>history.push('/entry-details')}
            extra={
                <Button
                    type={'danger'}
                    disabled={!selectedUserList.length}
                    onClick={()=>{
                        dispatch({
                            type: actions.DELETE_MODAL_VISIBLE,
                            payload: true
                        })
                    }}
                >Delete
                </Button>
            }
        />
        <Row type={'flex'} justify={'center'}>
            <Col xs={22}>
                <Table
                    columns={columns}
                    dataSource={userDetail}
                    pagination={{
                        position: ['bottomCenter'],
                        total: userDetail.length,
                        showSizeChanger: true,
                    }}
                    rowSelection={{
                        type: 'checkbox',
                        ...rowSelection,
                    }}
                    rowKey={record=>record.id}
                />
            </Col>
        </Row>
          <Modal
              visible={deleteModalVisible}
              title={'Remove User List'}
              maskClosable
              onOk={()=>{
                  dispatch({
                      type: actions.REMOVE_USER_LIST
                  })
              }}
              onCancel={()=>{
                  dispatch({
                      type: actions.DELETE_MODAL_VISIBLE,
                      payload: false,
                  })
              }}
            >
              Are you sure {selectedUserList.length} selected list in User Table
          </Modal>
      </>
    )
}

export default ListTable;