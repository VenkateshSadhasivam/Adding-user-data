import React from 'react';
import {
    Form,
    Input,
    Select,
    Button,
    Row,
    Col,
    Typography,
} from 'antd';
import shortId from 'shortid';
import { useDispatch } from "react-redux";
import actions from 'redux/app/actions';
import { history } from "redux/store";
import 'components/userdata.scss';

const { Option } = Select;
const { Title } =Typography;

const formItemLayout = {
    labelCol: {
        xs: {
            span: 24,
        },
        sm: {
            span: 24,
        },
    },
    wrapperCol: {
        xs: {
            span: 24,
        },
        sm: {
            span: 24,
        },
    },
};

const CreateUser = () => {
    const [form] = Form.useForm(null);
    const dispatch = useDispatch();

    const onFinish = values => {
        dispatch({
            type:actions.ADD_NEW_USER,
            payload: {
                id: shortId.generate(),
                ...values,
                phoneNumber: `${values.prefix} ${values.phone}`,
            }
        })
        form.resetFields();
        history.push('/list');
    };

    const prefixSelector = (
        <Form.Item name="prefix" noStyle>
            <Select
                style={{
                    width: 70,
                }}
            >
                <Option value="+86">+86</Option>
                <Option value="+91">+91</Option>
                <Option value="+4">+4</Option>
                <Option value="+1">+1</Option>
                <Option value="+87">+87</Option>
            </Select>
        </Form.Item>
    );

    return (
        <Row type={'flex'} justify={'center'}>
          <Col  xs={24} lg={24} className={'title'}><Title> Add User Details</Title></Col>
          <Col xs={24} lg={12}>
            <Form
              {...formItemLayout}
              form={form}
              name="register-Form"
              onFinish={onFinish}
              initialValues={{
                prefix: '+86',
              }}
              scrollToFirstError
              hideRequiredMark
            >
                <Form.Item
                    name="username"
                    label="UserName"
                    rules={[
                        {
                            required: true,
                            whitespace: true,
                            message: 'Please input your username',
                        },
                        () => ({
                            validator(rule, value) {
                                let userNameValidation = /^[a-zA-Z0-9]+([_ -]?[a-zA-Z0-9])*$/;
                                let userName = value ? value.trim(): '';
                                if (userName.length >0 && !userNameValidation.test(userName)) {
                                    return Promise.reject('Invalid UserName');
                                }
                                return Promise.resolve();
                            },
                        }),
                    ]}
                >
                    <Input max={50} />
                </Form.Item>
                <Form.Item
                    name="phone"
                    label="Phone Number"
                    rules={[
                        {
                            required: true,
                            whitespace: true,
                            message: 'Please input your phone number!',
                        },
                        () => ({
                            validator(rule, value) {
                                let phoneValidation = /^[0-9\b]+$/;
                                let phoneNumber = value? value.trim(): '';
                               if (phoneNumber.length >0 && phoneNumber.length === 10 && !phoneValidation.test(phoneNumber)) {
                                    return Promise.reject('Phone Number must be number');
                                }else if (phoneNumber.length > 0 && phoneNumber.length !== 10 && !phoneValidation.test(phoneNumber)) {
                                    return Promise.reject('Phone Number must be number and should be 10 characters');
                                }else if (phoneNumber.length > 0 && phoneNumber.length !== 10) {
                                    return Promise.reject('Phone Number must be 10 number');
                                }
                                return Promise.resolve();
                             },
                        }),
                    ]}
                >
                    <Input
                        addonBefore={prefixSelector}
                        style={{
                            width: '100%',
                        }}
                    />
                </Form.Item>
                <Form.Item
                    name="address"
                    label="Address"
                    rules={[
                        {
                            required: true,
                            whitespace: true,
                            message: 'Please input your address',
                        },
                    ]}
                >
                    <Input.TextArea  autoSize={{ minRows: 3, maxRows: 8 }} />
                </Form.Item>
                <Form.Item className={'submit-button'}>
                    <Button type="primary" htmlType="submit">
                        Register
                    </Button>
                </Form.Item>
            </Form>
          </Col>
        </Row>
    );
};

export default CreateUser;