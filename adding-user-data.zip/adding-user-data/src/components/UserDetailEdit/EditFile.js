import React from 'react';
import {
    Form,
    Input,
    Select,
    Button,
    Row,
    Col,
    Typography,
    Modal,
} from 'antd';
import { useDispatch, useSelector } from "react-redux";
import shortId from 'shortid';
import actions from 'redux/app/actions';
import 'components/userdata.scss';

const { Option } = Select;
const { Title } =Typography;

const formItemLayout = {
    labelCol: {
        xs: {
            span: 24,
        },
        sm: {
            span: 24,
        },
    },
    wrapperCol: {
        xs: {
            span: 24,
        },
        sm: {
            span: 24,
        },
    },
};

const EditUser = () => {
    const [form] = Form.useForm(null);
    const { editModalVisible, editFormValue, editLoader} = useSelector(state=> state.App)
    const dispatch = useDispatch();

    const onFinish = values => {
        dispatch({
            type:actions.EDIT_USER_DETAIL,
            payload: {
                id: shortId.generate(),
                ...values,
                phoneNumber: `${values.prefix} ${values.phone}`,
            }
        })
    };

    const prefixSelector = (
        <Form.Item name="prefix" noStyle>
            <Select
                style={{
                    width: 70,
                }}
            >
                <Option value="+86">+86</Option>
                <Option value="+91">+91</Option>
                <Option value="+4">+4</Option>
                <Option value="+1">+1</Option>
                <Option value="+87">+87</Option>
            </Select>
        </Form.Item>
    );

    return (
        <Modal
            visible={editModalVisible}
            onCancel={()=>{
                dispatch({
                    type: actions.EDIT_MODAL_VISIBLE,
                    payload: false,
                })
                dispatch({
                    type: actions.SET_FORM_VALUE,
                    payload:{}
                })
                form.resetFields();
            }}
            footer={null}
            maskClosable
            title={null}
            destroyOnClose={true}
        >
        <Row type={'flex'} justify={'center'}>
            <Col  xs={24} lg={24} className={'title'}><Title> Edit User Details</Title></Col>
            <Col xs={24}>
                <Form
                    {...formItemLayout}
                    form={form}
                    name="edit-Form"
                    onFinish={onFinish}
                    initialValues={{
                       username: editFormValue.username,
                        phone: editFormValue.phone,
                        prefix: editFormValue.prefix,
                        address: editFormValue.address
                    }}
                    scrollToFirstError
                    hideRequiredMark
                >
                    <Form.Item
                        name="username"
                        label="UserName"
                        rules={[
                            {
                                required: true,
                                whitespace: true,
                                message: 'Please input your username',
                            },
                            () => ({
                                validator(rule, value) {
                                    let userNameValidation = /^[a-zA-Z0-9]+([_ -]?[a-zA-Z0-9])*$/;
                                    let userName = value ? value.trim(): '';
                                    if (userName.length >0 && !userNameValidation.test(userName)) {
                                        return Promise.reject('Invalid UserName');
                                    }
                                    return Promise.resolve();
                                },
                            }),
                        ]}
                    >
                        <Input max={50} />
                    </Form.Item>
                    <Form.Item
                        name="phone"
                        label="Phone Number"
                        rules={[
                            {
                                required: true,
                                whitespace: true,
                                message: 'Please input your phone number!',
                            },
                            () => ({
                                validator(rule, value) {
                                    let phoneValidation = /^[0-9\b]+$/;
                                    let phoneNumber = value? value.trim(): '';
                                    if (phoneNumber.length >0 && phoneNumber.length === 10 && !phoneValidation.test(phoneNumber)) {
                                        return Promise.reject('Phone Number must be number');
                                    }else if (phoneNumber.length > 0 && phoneNumber.length !== 10 && !phoneValidation.test(phoneNumber)) {
                                        return Promise.reject('Phone Number must be number and should be 10 characters');
                                    }else if (phoneNumber.length > 0 && phoneNumber.length !== 10) {
                                        return Promise.reject('Phone Number must be 10 number');
                                    }
                                    return Promise.resolve();
                                },
                            }),
                        ]}
                    >
                        <Input
                            addonBefore={prefixSelector}
                            style={{
                                width: '100%',
                            }}
                        />
                    </Form.Item>
                    <Form.Item
                        name="address"
                        label="Address"
                        rules={[
                            {
                                required: true,
                                whitespace: true,
                                message: 'Please input your address',
                            },
                        ]}
                    >
                        <Input.TextArea  autoSize={{ minRows: 3, maxRows: 8 }} />
                    </Form.Item>
                    <Form.Item className={'submit-button'}>
                        <Button type="primary" htmlType="submit" loading={editLoader}>
                            Register
                        </Button>
                    </Form.Item>
                </Form>
            </Col>
        </Row>
        </Modal>
    );
};

export default EditUser;