import asyncComponent from 'components/Helper/asyncComponent';

const publicRoutes = [
  {
    path: '/',
    component: asyncComponent(() => import('containers/UserData/UserData')),
  },
  {
    path: '/entry-details',
    component: asyncComponent(() => import('containers/UserData/UserData')),
  },
  {
    path: '/list',
    component: asyncComponent(() => import('containers/EdirDeleteDetails/ListEditDelete')),
  },
  {
    path: '*',
    component: asyncComponent(() => import('containers/Pages/NotFound')),
  },
];

export default publicRoutes;
