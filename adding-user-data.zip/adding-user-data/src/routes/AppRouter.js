import React from 'react';
import { Route, Switch } from 'react-router-dom';
import privateRoutes from 'routes/publicRoutes';

const AppRouter = () => {
  return (
    <Switch>
      {privateRoutes.map((singleRoute) => (
        <Route
          exact
          key={singleRoute.path}
          path={`${singleRoute.path}`}
          component={singleRoute.component}
        />
      ))}
    </Switch>
  );
};

export default AppRouter;
